package com.ecommerce;
public class FraudDetectionService {
    public int suspicious(String productId, String customerId, String address, double amount) {
        System.out.println("[FraudDetectionService] Step 1: Running fraud rules for customer: " + customerId);
        System.out.println("[FraudDetectionService] Step 2: Computing risk score for order of $" + amount);
        int result=0;
        if (result==1) {
            System.out.println("[FraudDetectionService] Step 3: Order flagged as suspicious.");
        } else {
            System.out.println("[FraudDetectionService] Step 3: Order is legitimate.");
        }
        return result;
    }
}